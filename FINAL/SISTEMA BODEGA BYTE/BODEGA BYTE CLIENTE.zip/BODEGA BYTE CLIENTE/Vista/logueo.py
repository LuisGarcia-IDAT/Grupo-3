import hashlib
import socket
from datetime import datetime
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QMessageBox


# ------------------- Clase principal -------------------
class LoguearseApp(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Ui/LOGIN.ui" , self)
        self.setWindowTitle("LOGIN - BOGEDA BYTE")

        # CONEXIONES DE BOTONES
        self.btnIngresar.clicked.connect(self.validar_login)
        self.btnSalir.clicked.connect(self.salir_logueo)


        # Ocultar caracteres de la contraseña
        self.txtContrasena.setEchoMode(2)

    # ------------------- Función SHA256 -------------------
    def encriptar_sha256(self, texto):
        return hashlib.sha256(texto.encode('utf-8')).hexdigest()


    # ------------------- VALIDAR LOGIN -------------------
    def validar_login(self):
        usuario_ingresado = self.txtUsuario.text()
        contrasena_texto_plano = self.txtContrasena.text()
        
        # 1. ENCRIPTAMOS LO QUE ESCRIBIÓ EL USUARIO
        # Si el usuario escribe "hola", esto lo convierte en "b6f3..."
        hash_ingresado = self.encriptar_sha256(contrasena_texto_plano)

        usuario_encontrado = False

        # 2. BUSCAMOS EN EL ARCHIVO DE TEXTO
        try:
            with open("base_datos_usuarios.txt", "r", encoding="utf-8") as archivo:
                for linea in archivo:
                    linea = linea.strip()
                    if not linea: continue 
                    
                    datos = linea.split(",") # Separamos Usuario,Hash
                    
                    if len(datos) == 2:
                        user_archivo = datos[0]
                        hash_guardado = datos[1] # Esta es la clave encriptada del archivo

                        # 3. COMPARAMOS: ¿El hash generado es igual al hash guardado?
                        if usuario_ingresado == user_archivo and hash_ingresado == hash_guardado:
                            usuario_encontrado = True
                            break 
                            
        except FileNotFoundError:
            pass # Si no hay archivo, simplemente no entrará

        # ------------------- RESULTADO -------------------
        if usuario_encontrado:
            QMessageBox.information(self, "Acceso permitido", f"Bienvenido nuevamente, {usuario_ingresado}.")
            self.ver_cliente()
            self.close()
        else:
            QMessageBox.warning(self, "Acceso denegado", "Usuario no registrado o contraseña incorrecta.")
            self.registrar_fallo(usuario_ingresado)
            self.txtContrasena.clear()
            self.txtUsuario.setFocus()


    #REGISTRA LOS FALLOS AL INGRESAR COMO USUARIO
    def registrar_fallo(self, usuario):
        try:
            fecha_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ip_local = socket.gethostbyname(socket.gethostname())
            with open("intentos_fallidos.txt", "a", encoding="utf-8") as archivo:
                archivo.write(f"{fecha_hora} - Usuario: {usuario} - Intento fallido - IP: {ip_local}\n")
        except:
            pass


    # ------------------- ABRIR MENU PRINCIPAL -------------------
    def ver_cliente(self):
        from Vista.verCliente import verClienteApp
        self.ver_cliente = verClienteApp()
        self.ver_cliente.show()

    # ------------------- CERRAR LOGIN -------------------
    def salir_logueo(self):
        from Vista.clienteNo import ClienteNoApp
        self.salir_log = ClienteNoApp()
        self.salir_log.show()
        self.close()
