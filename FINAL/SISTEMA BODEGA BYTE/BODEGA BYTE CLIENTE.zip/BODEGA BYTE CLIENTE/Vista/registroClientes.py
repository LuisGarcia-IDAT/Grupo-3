from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QMessageBox, QMainWindow
import hashlib


class VentanaRegistro(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Ui/REGISTRO_USUARIO.ui" , self)
        self.setWindowTitle("REGISTRO USUARIO- BOGEDA BYTE")


        # 2. CONFIGURACIÓN DE SEGURIDAD
        self.txtContrasena.setEchoMode(QtWidgets.QLineEdit.Password)
        self.txtConfirmarContra.setEchoMode(QtWidgets.QLineEdit.Password)

        # 3. CONECTAR BOTONES
        self.btnRegistrarse.clicked.connect(self.validar_registro)
        self.btnCancelar.clicked.connect(self.cancelar)

    def validar_registro(self):
        nombre = self.txtNombre.text()
        usuario = self.txtUsuario.text()
        telefono = self.txtCell.text()
        password = self.txtContrasena.text()
        confirmar_pass = self.txtConfirmarContra.text()

        # 1. Validar vacíos
        if not nombre or not usuario or not password:
            QMessageBox.warning(self, "Campos Incompletos", "Por favor, llene todos los campos obligatorios.")
            return

        # 2. Validar coincidencia
        if password != confirmar_pass:
            QMessageBox.warning(self, "Error de Contraseña", "Las contraseñas no coinciden.")
            return

        # 3. GUARDAR EN ARCHIVO 
       
        try:
            pass_encriptada = hashlib.sha256(password.encode('utf-8')).hexdigest()
            
            with open("base_datos_usuarios.txt", "a", encoding="utf-8") as archivo:
                archivo.write(f"{usuario},{pass_encriptada}\n")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo guardar el usuario: {e}")
            return

        QMessageBox.information(self, "Registro Exitoso", f"El usuario '{usuario}' ha sido registrado correctamente.")
        
        self.cancelar()

    def cancelar(self):
        from Vista.CuadroNo import CuadroNoApp 
        self.ventana_anterior = CuadroNoApp()
        self.ventana_anterior.show()

        self.close()