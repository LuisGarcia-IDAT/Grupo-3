import sys
from PyQt5.QtWidgets import QApplication
from Vista.logueo import LoguearseApp
from Vista.sisprincipal import MenuAPP

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Creamos la instancia de tu ventana
    loguin = LoguearseApp()
    loguin.show()
    
    
    # Ejecutamos la aplicación
    sys.exit(app.exec_())
    