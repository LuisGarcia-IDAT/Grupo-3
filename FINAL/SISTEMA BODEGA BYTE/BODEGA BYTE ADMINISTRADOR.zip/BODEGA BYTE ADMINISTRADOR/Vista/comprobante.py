from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem
from datetime import datetime
import os
import webbrowser
import unicodedata
from reportlab.pdfgen import canvas
import urllib.parse


class ComprobanteAPP(QMainWindow):

    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi("Ui/COMPROBANTE_PAGO.ui", self)
        self.setWindowTitle("Comprobante")

        # -------------------- Eventos UI --------------------
        self.btnRegresarComprobante.clicked.connect(self.regresar_menu_desde_comprobante)
        self.btnEnviar.clicked.connect(self.enviar_comprobante)
        self.btnGenerarPDF.clicked.connect(self.generar_pdf)

        # Campos de producto
        self.txtProducto.textChanged.connect(self.autocompletar_por_nombre)
        self.txtCodigo.textChanged.connect(self.autocompletar_por_codigo)
        self.txtCantidad.textChanged.connect(self.calcular_total)
        self.txtCantidad.textChanged.connect(self.actualizar_totales_generales)
        self.txtValorUnitario.textChanged.connect(self.actualizar_totales_generales)

        # Pago
        self.txtPagoCon.textChanged.connect(self.actualizar_vuelto)

        # Comprobante
        self.cboTipoComprobante.currentTextChanged.connect(self.cambiar_tipo_comprobante)

        # Tabla de productos
        self.btnAgregarProducto.clicked.connect(self.agregar_producto_a_tabla)
        self.btnEliminarProducto.clicked.connect(self.eliminar_producto_seleccionado)
        self.tblDetalle.itemChanged.connect(self.calcular_totales_desde_tabla)

        # Fecha automática
        self.txtFecha.setText(datetime.now().strftime("%d/%m/%Y"))

        # Datos base de productos
        self.cargar_productos_inventario()



        

    # =========================================================
    # GENERAR PDF
    # =========================================================
    def generar_pdf(self):
        """Genera un comprobante PDF con los datos del formulario."""

        tipo_comprobante = self.cboTipoComprobante.currentText()
        nro_comprobante = self.lblNumComprobante.text().strip()
        tipo_doc = self.cboTipoDoc.currentText()
        num_doc = self.txtNumDocumento.text().strip()
        nombre = self.txtNombre.text().strip()
        direccion = self.txtDireccion.text().strip()
        telefono = self.txtTelefono.text().strip()
        num_operacion = self.txtNumOperacion.text().strip()
        metodo_pago = self.cboMetodoPago.currentText()
        fecha = self.txtFecha.text().strip()

        subtotal = self.txtSubTotal.text().strip()
        igv = self.txtIGV.text().strip()
        total = self.txtTotalPagar.text().strip()
        monto_letras = self.txtMontoLetras.text().strip()
        pago_con = self.txtPagoCon.text().strip()
        vuelto = self.txtVuelto.text().strip()

        # -------- Validaciones --------
        if tipo_comprobante == "Factura" and (not num_doc.isdigit() or len(num_doc) != 11):
            return QMessageBox.warning(self, "Error", "Para FACTURA el RUC debe tener 11 dígitos.")

        if tipo_comprobante == "Boleta" and tipo_doc == "DNI":
            if not num_doc.isdigit() or len(num_doc) != 8:
                return QMessageBox.warning(self, "Error", "El DNI debe tener 8 dígitos.")

        if not nombre or not total:
            return QMessageBox.warning(self, "Error", "Debe ingresar el nombre del cliente y el total.")

        # Crear carpeta si no existe
        ruta_carpeta = "Comprobantes"
        os.makedirs(ruta_carpeta, exist_ok=True)

        ruta_pdf = os.path.join(
            ruta_carpeta,
            f"Comprobante_{nombre}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        )

        # -------- Generación del PDF --------
        pdf = canvas.Canvas(ruta_pdf)

        # Encabezado principal
        pdf.setFont("Helvetica-Bold", 18)
        pdf.drawString(140, 810, "EMISIÓN DE COMPROBANTES DE PAGO")

        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(50, 780, "BODEGA BYTE")
        pdf.drawString(350, 780, "RUC: 20000000123")

        pdf.setFont("Helvetica", 12)
        pdf.drawString(50, 760, "AV. LAS PALMERAS 1597")
        pdf.drawString(350, 760, "TEL: 993431336")
        pdf.line(40, 745, 550, 745)

        # Datos del comprobante
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(50, 720, f"Comprobante de Pago - {tipo_comprobante}")

        pdf.setFont("Helvetica", 12)
        pdf.drawString(50, 700, f"N° de Comprobante: {nro_comprobante}")
        pdf.line(40, 690, 550, 690)

        # Datos cliente
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(50, 670, "Datos del Cliente")

        pdf.setFont("Helvetica", 12)
        pdf.drawString(50, 650, f"Tipo de Documento: {tipo_doc}")
        pdf.drawString(300, 650, f"N° Documento: {num_doc}")
        pdf.drawString(50, 630, f"Nombre: {nombre}")
        pdf.drawString(300, 630, f"N° Operación: {num_operacion}")
        pdf.drawString(50, 610, f"Dirección: {direccion}")
        pdf.drawString(300, 610, f"Método de Pago: {metodo_pago}")
        pdf.drawString(50, 590, f"N° Teléfono: {telefono}")
        pdf.drawString(300, 590, f"Fecha: {fecha}")

        pdf.line(40, 575, 550, 575)

        # -------- Tabla de productos --------
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(50, 555, "Detalle del Producto")

        pdf.setFont("Helvetica-Bold", 12)
        y = 535
        pdf.drawString(50, y, "Código")
        pdf.drawString(120, y, "Producto")
        pdf.drawString(240, y, "Descripción")
        pdf.drawString(390, y, "Cant")
        pdf.drawString(440, y, "P.Unit")
        pdf.drawString(500, y, "Total")

        # Contenido de la tabla
        pdf.setFont("Helvetica", 11)
        y -= 20

        for r in range(self.tblDetalle.rowCount()):
            codigo = self.tblDetalle.item(r, 0).text()
            prod = self.tblDetalle.item(r, 1).text()
            desc = self.tblDetalle.item(r, 3).text()
            cant = self.tblDetalle.item(r, 2).text()
            precio = self.tblDetalle.item(r, 4).text()
            total_prod = self.tblDetalle.item(r, 5).text()

            pdf.drawString(50, y, codigo)
            pdf.drawString(120, y, prod[:14])
            pdf.drawString(240, y, desc[:20])
            pdf.drawString(390, y, cant)
            pdf.drawString(440, y, precio)
            pdf.drawString(500, y, total_prod)

            y -= 16
            if y < 120:
                pdf.showPage()
                y = 800

        # -------- Totales --------
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(50, 420, "Totales de la Operación")

        pdf.setFont("Helvetica", 12)
        pdf.drawString(50, 400, f"SubTotal: {subtotal}")
        pdf.drawString(50, 380, f"IGV: {igv}")
        pdf.drawString(50, 360, f"Total a Pagar: {total}")
        pdf.drawString(50, 340, f"Monto en Letras: {monto_letras}")
        pdf.drawString(50, 320, f"Pago Con: {pago_con}")
        pdf.drawString(50, 300, f"Vuelto: {vuelto}")

        pdf.line(40, 280, 550, 280)
        pdf.setFont("Helvetica-Bold", 13)
        pdf.drawString(180, 260, "¡Gracias por su compra! :D")

        pdf.save()

        QMessageBox.information(self, "PDF Generado", f"Comprobante guardado:\n{ruta_pdf}")

    # =========================================================
    # ENVÍO DE WHATSAPP
    # =========================================================
    def enviar_comprobante(self):
        """Abre WhatsApp Web con mensaje básico al cliente."""

        cliente = self.txtNombre.text().strip()
        telefono = self.txtTelefono.text().strip()

        if not telefono:
            return QMessageBox.warning(self, "Error", "Debe ingresar un número de teléfono.")

        mensaje = urllib.parse.quote(f"Hola {cliente}, tu comprobante de pago ya está listo.")
        telefono_limpio = telefono.replace(" ", "").replace("-", "")
        enlace = f"https://wa.me/51{telefono_limpio}?text={mensaje}"

        webbrowser.open(enlace)
        QMessageBox.information(self, "WhatsApp", "Se abrió WhatsApp Web.")

    # =========================================================
    # MENÚ PRINCIPAL
    # =========================================================
    def regresar_menu_desde_comprobante(self):
        """Retorna a la ventana principal."""
        from Vista.sisprincipal import MenuAPP
        self.ventana_menu = MenuAPP()
        self.ventana_menu.show()
        self.close()

    # =========================================================
    # CAMBIO DE TIPO DE COMPROBANTE
    # =========================================================
    def cambiar_tipo_comprobante(self):
        """Cambia campos según Boleta o Factura."""
        tipo = self.cboTipoComprobante.currentText()

        if tipo == "Factura":
            self.cboTipoDoc.setCurrentText("RUC")
            self.cboTipoDoc.setEnabled(False)
            self.txtNumDocumento.setPlaceholderText("Ingrese RUC (11 dígitos)")
            self.txtNombre.setPlaceholderText("Razón Social")
        else:
            self.cboTipoDoc.setEnabled(True)
            self.cboTipoDoc.setCurrentText("DNI")
            self.txtNumDocumento.setPlaceholderText("Ingrese DNI")
            self.txtNombre.setPlaceholderText("Nombre del cliente")

    # =========================================================
    # PRODUCTOS: AUTOCOMPLETAR / AGREGAR / ELIMINAR
    # =========================================================
    def quitar_tildes(self, texto):
        return "".join(
            c for c in unicodedata.normalize("NFD", texto)
            if unicodedata.category(c) != "Mn"
        )



    def autocompletar_por_nombre(self):
        nombre_input = self.txtProducto.text().strip()

        if not nombre_input:
            return

        nombre_sin_tildes = self.quitar_tildes(nombre_input.lower())

        for nombre, datos in self.productos.items():
            nombre_producto_sin_tildes = self.quitar_tildes(nombre.lower())

            if nombre_sin_tildes == nombre_producto_sin_tildes:

                self.txtCodigo.blockSignals(True)
                self.txtDescripcion.blockSignals(True)
                self.txtValorUnitario.blockSignals(True)

                self.txtCodigo.setText(datos.get("codigo", ""))
                self.txtDescripcion.setText(datos.get("descripcion", ""))
                self.txtValorUnitario.setText(str(datos.get("precio", 0.0)))

                self.txtCodigo.blockSignals(False)
                self.txtDescripcion.blockSignals(False)
                self.txtValorUnitario.blockSignals(False)
                return


    def autocompletar_por_codigo(self):
        codigo_input = self.txtCodigo.text().strip()

        # No hacer nada si está vacío
        if not codigo_input:
            return

        # Buscar coincidencia exacta por código
        for nombre, datos in self.productos.items():
            codigo = datos.get("codigo", "").strip()

            # AUTOCOMPLETAR SOLO SI LA LONGITUD COINCIDE
            if len(codigo_input) == len(codigo) and codigo == codigo_input:
                self.txtProducto.blockSignals(True)
                self.txtDescripcion.blockSignals(True)
                self.txtValorUnitario.blockSignals(True)

                self.txtProducto.setText(nombre)
                self.txtDescripcion.setText(datos.get("descripcion", ""))
                self.txtValorUnitario.setText(str(datos.get("precio", 0.0)))

                self.txtProducto.blockSignals(False)
                self.txtDescripcion.blockSignals(False)
                self.txtValorUnitario.blockSignals(False)
                return

        # Si el código tiene la longitud correcta pero no existe → limpiar
        for nombre, datos in self.productos.items():
            codigo = datos.get("codigo", "").strip()
            if len(codigo_input) == len(codigo):
                self.txtProducto.clear()
                self.txtDescripcion.clear()
                self.txtValorUnitario.clear()
                return




    def agregar_producto_a_tabla(self):
        """Añade un producto a la tabla."""

        codigo = self.txtCodigo.text().strip()
        producto = self.txtProducto.text().strip()
        descripcion = self.txtDescripcion.text().strip()
        cantidad = float(self.txtCantidad.text() or 0)
        precio = float(self.txtValorUnitario.text() or 0)
        total = round(cantidad * precio, 2)

        if not producto and not codigo:
            return QMessageBox.warning(self, "Error", "Debe ingresar un producto.")

        fila = self.tblDetalle.rowCount()
        self.tblDetalle.insertRow(fila)

        self.tblDetalle.setItem(fila, 0, QTableWidgetItem(codigo))
        self.tblDetalle.setItem(fila, 1, QTableWidgetItem(producto))
        self.tblDetalle.setItem(fila, 3, QTableWidgetItem(descripcion))
        self.tblDetalle.setItem(fila, 2, QTableWidgetItem(str(cantidad)))
        self.tblDetalle.setItem(fila, 4, QTableWidgetItem(str(precio)))
        self.tblDetalle.setItem(fila, 5, QTableWidgetItem(str(total)))

        # Limpiar campos
        self.txtCodigo.clear()
        self.txtProducto.clear()
        self.txtDescripcion.clear()
        self.txtCantidad.clear()
        self.txtValorUnitario.clear()
        self.txtTotal.clear()

        self.calcular_totales_desde_tabla()

    def eliminar_producto_seleccionado(self):
        """Elimina la fila seleccionada en la tabla."""
        seleccion = self.tblDetalle.selectedItems()

        if not seleccion:
            return QMessageBox.warning(self, "Advertencia", "Seleccione un producto.")

        self.tblDetalle.removeRow(seleccion[0].row())
        self.calcular_totales_desde_tabla()

    # =========================================================
    # CALCULO DE TOTALES
    # =========================================================
    def calcular_total(self, _=None):
        """Calcula el total de un solo producto."""
        try:
            return float(self.txtCantidad.text()) * float(self.txtValorUnitario.text())
        except:
            return 0

    def actualizar_totales_generales(self, _=None):
        """Actualiza total, subtotal, IGV y monto en letras del producto actual."""
        total_producto = round(self.calcular_total(), 2)
        self.txtTotal.setText(str(total_producto))

    def calcular_totales_desde_tabla(self, _=None):
        """Recalcula totales en base a toda la tabla."""
        subtotal = 0.0

        for r in range(self.tblDetalle.rowCount()):
            try:
                subtotal += float(self.tblDetalle.item(r, 5).text())
            except:
                pass

        subtotal = round(subtotal, 2)
        igv = round(subtotal * 0.18, 2)
        total = round(subtotal + igv, 2)

        self.txtSubTotal.setText(str(subtotal))
        self.txtIGV.setText(str(igv))
        self.txtTotalPagar.setText(str(total))

        entero = int(total)
        cent = int(round((total - entero) * 100))
        self.txtMontoLetras.setText(f"{entero} con {cent:02d}/100 soles")

        self.actualizar_vuelto()

    def actualizar_vuelto(self, _=None):
        """Calcula el vuelto del cliente."""
        try:
            pago = float(self.txtPagoCon.text())
            total = float(self.txtTotalPagar.text())
            self.txtVuelto.setText(str(max(round(pago - total, 2), 0)))
        except:
            self.txtVuelto.setText("0.00")
    def cargar_productos_inventario(self):
        """Carga los productos desde Inventario.txt a un diccionario."""
        ruta = "Modelo/Inventario.txt"
        self.productos = {}

        if not os.path.exists(ruta):
            return

        with open(ruta, "r", encoding="utf-8") as f:
            for linea in f:
                partes = linea.strip().split("|")
                if len(partes) == 10:
                    codigo, nombre, categoria, precio, stock, stock_min, alerta, estado, fecha, proveedor = partes
                    
                    # Solo productos habilitados y con stock
                    if estado.lower() == "habilitado":
                        self.productos[nombre] = {
                            "codigo": codigo,
                            "descripcion": categoria,
                            "precio": float(precio),
                            "stock": int(stock)
                    }
