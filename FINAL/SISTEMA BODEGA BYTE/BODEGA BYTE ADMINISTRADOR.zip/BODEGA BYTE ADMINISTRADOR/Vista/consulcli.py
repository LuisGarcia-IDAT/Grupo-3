from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox
from PyQt5.QtCore import Qt
from datetime import datetime
import os


class ConsultaCli(QMainWindow):

    # =========================================================
    #   CONSTRUCTOR
    # =========================================================
    def __init__(self, parent=None):
        super().__init__(parent)

        uic.loadUi("Ui/CONSULTA_CLIENTE.ui", self)
        self.setWindowTitle("CONSULTA DE CLIENTES")

        self.clientes_registrados = []
        self.form_cliente = None
        self.indice_editar = None

        self.cargar_clientes_desde_archivo()
        self.conectar_botones()
        self.configurar_tabla()
        self.cargar_clientes_en_tabla()

        if hasattr(self, "lblFecha"):
            self.lblFecha.setText(datetime.now().strftime("%d/%m/%Y"))

    # =========================================================
    #   CONEXIONES DE BOTONES
    # =========================================================
    def conectar_botones(self):
        self.btnRegresarCliente.clicked.connect(self.regresar_menu_desde_consulta)
        self.btnAgregarCliente.clicked.connect(self.abrir_form_cliente)
        self.btnBuscarCliente.clicked.connect(self.buscar_cliente_tabla)
        self.btnEditarCliente.clicked.connect(self.abrir_form_editar_cliente)
        self.btnEliminarCliente.clicked.connect(self.eliminar_cliente)
        self.btnActualizarCliente.clicked.connect(self.actualizar_tabla)

        if hasattr(self, "txtBuscarCliente"):
            self.txtBuscarCliente.returnPressed.connect(self.buscar_cliente_tabla)

    # =========================================================
    #   TABLA - CONFIGURACIÓN Y CARGA
    # =========================================================
    def configurar_tabla(self):
        """Define columnas de la tabla."""
        if not hasattr(self, "tblClientes"):
            return

        self.tblClientes.setColumnCount(8)

        # 🔒 Bloquear edición de celdas
        from PyQt5.QtWidgets import QAbstractItemView
        self.tblClientes.setEditTriggers(QAbstractItemView.NoEditTriggers)


    def cargar_clientes_en_tabla(self):
        """Carga los clientes registrados en la tabla."""
        if not hasattr(self, "tblClientes"):
            return

        self.tblClientes.setRowCount(0)

        for fila, datos in enumerate(self.clientes_registrados):
            self.tblClientes.insertRow(fila)
            for col, valor in enumerate(datos):
                self.tblClientes.setItem(fila, col, QTableWidgetItem(str(valor)))

        self.actualizar_total_clientes()
        self.tblClientes.clearSelection()

    def actualizar_total_clientes(self):
        """Actualiza el conteo de clientes en pantalla."""
        if hasattr(self, "lblTotalClientes"):
            self.lblTotalClientes.setText(f"Total de Clientes: {self.tblClientes.rowCount()}")

    # =========================================================
    #   BÚSQUEDA
    # =========================================================
    def buscar_cliente_tabla(self):
        """Filtra filas según texto ingresado."""
        if not hasattr(self, "txtBuscarCliente"):
            return

        texto = self.txtBuscarCliente.text().lower().strip()

        for fila in range(self.tblClientes.rowCount()):
            mostrar = any(
                texto in (self.tblClientes.item(fila, col).text().lower() if self.tblClientes.item(fila, col) else "")
                for col in range(self.tblClientes.columnCount())
            )
            self.tblClientes.setRowHidden(fila, not mostrar)

        visibles = sum(not self.tblClientes.isRowHidden(i) for i in range(self.tblClientes.rowCount()))
        if hasattr(self, "lblTotalClientes"):
            self.lblTotalClientes.setText(f"Total de Clientes: {visibles}")

    # =========================================================
    #   ARCHIVOS - CARGAR / GUARDAR
    # =========================================================
    def cargar_clientes_desde_archivo(self):
        """Lee clientes desde archivo."""
        ruta = "Modelo/Clientes.txt"

        os.makedirs("Modelo", exist_ok=True)

        if not os.path.exists(ruta):
            open(ruta, "w", encoding="utf-8").close()
            return

        self.clientes_registrados.clear()

        with open(ruta, "r", encoding="utf-8") as archivo:
            for linea in archivo:
                datos = linea.strip().split(";")
                if len(datos) == 8:
                    self.clientes_registrados.append(tuple(datos))

    def grabar_clientes_en_archivo(self):
        """Guarda los clientes en el archivo."""
        ruta = "Modelo/Clientes.txt"
        os.makedirs("Modelo", exist_ok=True)

        with open(ruta, "w", encoding="utf-8") as archivo:
            for cli in self.clientes_registrados:
                archivo.write(";".join(cli) + "\n")

    # =========================================================
    #   FORMULARIO DE NUEVO CLIENTE
    # =========================================================
    def abrir_form_cliente(self):
        """Abre formulario vacío para registrar cliente."""
        try:
            self.form_cliente = uic.loadUi("Ui/FORM_CLIENTE.ui")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo cargar FORM_CLIENTE.ui: {e}")
            return

        self.form_cliente.btnGuardarCliente.clicked.connect(self.guardar_cliente_desde_form)
        self.form_cliente.btnCancelar.clicked.connect(self.cancelar_form_cliente)

        self.form_cliente.txtFecha.setText(datetime.now().strftime("%d/%m/%Y"))
        self.form_cliente.txtCodigo.setFocus()
        self.form_cliente.show()

    def guardar_cliente_desde_form(self):
        """Registra un nuevo cliente."""
        if not self.form_cliente:
            return

        def g(n): return getattr(self.form_cliente, n).text().strip()

        datos = (
            g("txtCodigo"), g("txtNombre"), g("txtDNI"), g("txtDireccion"),
            g("txtTelefono"), g("txtCorreo"), g("txtFecha"),
            self.form_cliente.cboEstado.currentText()
        )

        if not datos[0] or not datos[1]:
            QMessageBox.warning(self.form_cliente, "Error", "Debe ingresar código y nombre.")
            return

        self.clientes_registrados.append(datos)
        self.grabar_clientes_en_archivo()
        self.cargar_clientes_en_tabla()

        QMessageBox.information(self.form_cliente, "Éxito", "Cliente agregado correctamente.")
        self.form_cliente.close()
        self.form_cliente = None

    # =========================================================
    #   EDITAR CLIENTE
    # =========================================================
    def abrir_form_editar_cliente(self):
        """Abre formulario para editar cliente seleccionado."""
        seleccion = self.tblClientes.selectedItems()

        if not seleccion:
            QMessageBox.warning(self, "Advertencia", "Debe seleccionar un cliente para editar.")
            return

        fila = seleccion[0].row()
        self.indice_editar = fila

        try:
            self.form_cliente = uic.loadUi("Ui/FORM_CLIENTE.ui")
        except:
            QMessageBox.critical(self, "Error", "No se pudo cargar FORM_CLIENTE.ui.")
            return

        self.form_cliente.btnGuardarCliente.clicked.connect(self.guardar_cambios_cliente)
        self.form_cliente.btnCancelar.clicked.connect(self.cancelar_form_cliente)

        datos = self.clientes_registrados[fila]
        campos = ["txtCodigo", "txtNombre", "txtDNI", "txtDireccion",
                  "txtTelefono", "txtCorreo", "txtFecha"]

        for w, val in zip(campos, datos[:-1]):
            getattr(self.form_cliente, w).setText(str(val))

        self.form_cliente.cboEstado.setCurrentText(datos[-1])
        self.form_cliente.show()

    def guardar_cambios_cliente(self):
        """Guarda cambios del cliente editado."""
        if not self.form_cliente:
            return

        def g(n): return getattr(self.form_cliente, n).text().strip()

        datos = (
            g("txtCodigo"), g("txtNombre"), g("txtDNI"), g("txtDireccion"),
            g("txtTelefono"), g("txtCorreo"), g("txtFecha"),
            self.form_cliente.cboEstado.currentText()
        )

        self.clientes_registrados[self.indice_editar] = datos
        self.grabar_clientes_en_archivo()
        self.cargar_clientes_en_tabla()

        QMessageBox.information(self.form_cliente, "Éxito", "Cliente editado correctamente.")
        self.form_cliente.close()
        self.form_cliente = None

    # =========================================================
    #   ELIMINAR CLIENTE
    # =========================================================
    def eliminar_cliente(self):
        """Elimina cliente seleccionado."""
        seleccion = self.tblClientes.selectedItems()

        if not seleccion:
            QMessageBox.warning(self, "Advertencia", "Debe seleccionar un cliente para eliminar.")
            return

        fila = self.tblClientes.currentRow()
        codigo = self.tblClientes.item(fila, 0).text()

        confirm = QMessageBox.question(
            self, "Eliminar Cliente",
            f"¿Estás seguro de eliminar el cliente {codigo}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm != QMessageBox.Yes:
            return

        del self.clientes_registrados[fila]
        self.grabar_clientes_en_archivo()
        self.cargar_clientes_en_tabla()

        QMessageBox.information(self, "Éxito", f"Cliente '{codigo}' eliminado correctamente.")

    # =========================================================
    #   CANCELAR FORMULARIO
    # =========================================================
    def cancelar_form_cliente(self):
        """Cierra el formulario sin guardar."""
        if self.form_cliente:
            self.form_cliente.close()
            self.form_cliente = None

    # =========================================================
    #   ACTUALIZAR TABLA COMPLETA
    # =========================================================
    def actualizar_tabla(self):
        """Recarga clientes desde archivo."""
        self.cargar_clientes_desde_archivo()
        self.cargar_clientes_en_tabla()
        QMessageBox.information(self, "Actualizado", "Tabla actualizada.")

    # =========================================================
    #   REGRESAR AL MENÚ PRINCIPAL
    # =========================================================
    def regresar_menu_desde_consulta(self):
        """Regresa a la ventana principal."""
        try:
            from Vista.sisprincipal import MenuAPP
            self.ventana_menu = MenuAPP()
            self.ventana_menu.show()
            self.close()
        except Exception as e:
            QMessageBox.warning(self, "Advertencia", f"No se pudo abrir el menú: {e}")
