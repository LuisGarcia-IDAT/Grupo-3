from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow

class SalidaInventario(QMainWindow):
    def __init__(self, parent = None):
        super(SalidaInventario, self).__init__(parent)
        uic.loadUi("Ui/SALIDA_INVENTARIO.ui", self)
        self.setWindowTitle("SALIDA INVENTARIO") 

#CONEXION DE BOTONES
        self.btnRegresarSalida.clicked.connect(self.regresar_inventario_desde_salida)

#AREA DE PROGRAMACION
    def regresar_inventario_desde_salida(self):
        from Vista.inventario import Inventario
        self.ventana_inven = Inventario()
        self.ventana_inven .show()
        self.close()
    