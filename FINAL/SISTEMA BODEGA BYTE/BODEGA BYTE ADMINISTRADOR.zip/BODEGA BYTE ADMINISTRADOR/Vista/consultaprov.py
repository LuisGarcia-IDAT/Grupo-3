from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox
from datetime import datetime
import os

class ConsultaProveedores(QMainWindow):
    def __init__(self, parent = None):
        super(ConsultaProveedores, self).__init__(parent)
        uic.loadUi("Ui/CONSULTA_PROVEEDORES.ui", self)
        self.setWindowTitle("CONSULTA DE PROVEEDORES") 



    #DATOS PARA LAS TABLAS

        self.proveedores_registrados = []
        self.form_proveedores = None
        self.indice_proveedores = None

        self.cargar_proveedores_archivo()
        if hasattr(self, "lblFecha"):
            self.lblFecha.setText(datetime.now().strftime("%d/%m/%Y"))

        self.conectar_botones()
        self.configuracion_tabla()
        self.cargar_proveedores()


    #CONEXION DE BOTONES
    def conectar_botones(self):
        self.btnRegresarProveedor.clicked.connect(self.regresar_menu_desde_consulta_proveedores)
        self.btnAgregarProveedor.clicked.connect(self.abrir_form_proveedor)
        self.btnBuscarProveedor.clicked.connect(self.buscar_proveedores)
        self.btnEditarProveedor.clicked.connect(self.editar_form_cliente)
        self.btnEliminarProveedor.clicked.connect(self.eliminar_proveedor)
        self.btnActualizarProveedor.clicked.connect(self.actualizar_tabla)
        



    #DEF PARA FUNCIONAMIENTO DE LA TABLA

    def configuracion_tabla(self):
        if not hasattr(self, "tblProveedor"):
            return
        self.tblProveedor.setColumnCount(8)
        if self.tblProveedor.columnCount() != 8:
            self.tblProveedor.setColumnCount(8)



    #1 CARGA LOS PROVEEDORES DE LA LISTA
    def cargar_proveedores(self):
        if not hasattr(self, "tblProveedor"):
            return
        
        self.tblProveedor.setRowCount(0)

        for fila, datos in enumerate(self.proveedores_registrados):
            self.tblProveedor.insertRow(fila)
            for col, valor in enumerate(datos):
                self.tblProveedor.setItem(fila , col, QTableWidgetItem(str(valor)))
    

        self.actualizar_total_proveedores()
        self.tblProveedor.clearSelection()
    

    # 2 BUSCA LOS PROVEEDORES DE LA LISTA
    def buscar_proveedores(self):
        if not hasattr(self, "tblProveedor"):
            return
        
        texto = self.txtBuscar.text().lower().strip()

        if texto == "":
            for i in range(self.tblProveedor.rowCount()):
                self.tblProveedor.setRowHidden(i, False)
        else:
            for i in range(self.tblProveedor.rowCount()):
                visible = False
                for j in range(self.tblProveedor.columnCount()):
                    item = self.tblProveedor.item(i, j)
                    if item and texto in item.text().lower():
                        visible = True
                        break
                self.tblProveedor.setRowHidden(i, not visible)
        
        # CONTAR VISIBLES Y ACTUALIZAR
        visibles = sum(not self.tblProveedor.isRowHidden(i) for i in range(self.tblProveedor.rowCount()))
        
        if hasattr(self, "lblTotal"):
            # Solo ponemos el número, porque el texto "Total de..." ya está fijo a la izquierda
            self.lblTotal.setText(str(visibles))


    #3.1 ABRE EL FORMULARIO PARA AGREGAR A LOS PROVEEDORES
    def abrir_form_proveedor(self):
        try:
            self.form_proveedores = uic.loadUi("Ui/FORM_PROVEEDOR.UI")
        except Exception as e:
            QMessageBox.critical(self, "ERROR", f"No se pudo cargar FORM_PROVEEDOR")
            return
        

        self.form_proveedores.btnGuardarProveedor.clicked.connect(self.guardar_proveedor_form)
        self.form_proveedores.btnCancelar.clicked.connect(self.cancelar_form_proveedor)
        self.form_proveedores.show()


    #3.2 GUARDA LOS DATOS DE LOS PROVEEDORES DEL FORMULARIO

    def guardar_proveedor_form(self):
        if not self.form_proveedores:
            return
        
        def g(n):
            return getattr(self.form_proveedores, n).text().strip() if hasattr(self.form_proveedores, n) else ""
    
        datos = (
            g("txtCodigo"),
            g("txtNombre"),
            g("txtDNI"),
            g("txtDireccion"),
            g("txtTelefono"),
            g("txtCorreo"),
            g("txtFecha"),
            g("txtEstado")
        )

        if datos[0] == "" or datos[1] == "":
            QMessageBox.warning(self.form_proveedores, "ERROR", "DEBE INGRESAR CODIGO Y NOMBRE")
            return
        
        self.proveedores_registrados.append(datos)
        self.grabar_proveedores()

        fila = self.tblProveedor.rowCount()
        self.tblProveedor.insertRow(fila)
        for col, val in enumerate(datos):
            self.tblProveedor.setItem(fila, col, QTableWidgetItem(str(val)))

        QMessageBox.information(self.form_proveedores, "Éxito", "Proveedor agregado correctamente.")
        self.form_proveedores.close()
        self.form_proveedores = None



    #3.3 CANCELA EL FORMULARIO Y REGRESA A LA VENTANA PRINCIPAL

    def cancelar_form_proveedor(self):
        if self.form_proveedores:
            self.form_proveedores.close()
            self.form_proveedores = None
        self.show()

    #4 CARGA LOS CLIENTES DESDE EL ARCHIVO QUE SE CREO
    def cargar_proveedores_archivo(self):
        ruta = "Modelo/Proveedor.txt"

        if not os.path.exists("Modelo"):
            os.makedirs("Modelo")

        if not os.path.exists(ruta):
            open(ruta, "w", encoding="utf-8").close()
            return
        
        self.proveedores_registrados.clear()

        with open(ruta, "r", encoding="utf-8") as archivo:
            for linea in archivo:
                cols = linea.strip().split(";")
                if len(cols) == 8:
                    self.proveedores_registrados.append(tuple(cols))


    #5 GRABA CLIENTES EN EL ARCHIVO CREADO
    def grabar_proveedores(self):
        ruta = "Modelo/Proveedor.txt"

        if not os.path.exists("Modelo"):
            os.makedirs("Modelo")

        with open(ruta, "w", encoding="utf-8") as archivo:
            for cli in self.proveedores_registrados:
                archivo.write(";".join(cli) + "\n")


    #6 EDITA LOS CLIENTES
    def editar_form_cliente(self):
        seleccion = self.tblProveedor.selectedItems()

        if not seleccion:
            QMessageBox.warning(self, "Advertencia", "Debe seleccionar un Proveedor para editar")
            return
        
        fila = seleccion[0].row()
        self.indice_editar = fila

        try:
            self.form_proveedores = uic.loadUi("Ui/FORM_PROVEEDOR.ui")
        except:
            QMessageBox.critical(self, "Error", "No se pudo cargar FORM_PROVEEDOR,ui")
            return
        
        self.form_proveedores.btnGuardarProveedor.clicked.connect(self.guardar_cambios_proveedores)
        self.form_proveedores.btnCancelar.clicked.connect(self.cancelar_form_proveedor)

        nombres = ["txtCodigo","txtNombre","txtDNI","txtDireccion","txtTelefono","txtCorreo","txtFecha","txtEstado"]
        datos = self.proveedores_registrados[fila]

        for w, val in zip(nombres, datos):
            if hasattr(self.form_proveedores, w):
                getattr(self.form_proveedores, w).setText(str(val))

        self.form_proveedores.show()


    #7 GUARDA LOS CAMBIOS
    def guardar_cambios_proveedores(self):
        if not self.form_proveedores:
            return

        def g(n):
            return getattr(self.form_proveedores, n).text().strip() if hasattr(self.form_proveedores, n) else ""

        datos = (
            g("txtCodigo"),
            g("txtNombre"),
            g("txtDNI"),
            g("txtDireccion"),
            g("txtTelefono"),
            g("txtCorreo"),
            g("txtFecha"),
            g("txtEstado")
        )

        self.proveedores_registrados[self.indice_editar] = datos

        for col, val in enumerate(datos):
            self.tblProveedor.setItem(self.indice_editar, col, QTableWidgetItem(str(val)))

        self.grabar_proveedores()

        QMessageBox.information(self.form_proveedores, "Éxito", "Cliente editado correctamente.")
        self.form_proveedores.close()
        self.form_proveedores = None

    #8 ELIMINAR CLIENTES
    def eliminar_proveedor(self):
        seleccion = self.tblProveedor.selectedItems()

        if not seleccion:
            QMessageBox.warning(self, "Advertencia", "Debe seleccionar un proveedor para eliminar.")
            return

        fila = self.tblProveedor.currentRow()
        nombre = self.tblProveedor.item(fila, 1).text()

        confirm = QMessageBox.question(
            self,
            "Eliminar Proveedor",
            f"¿Estas seguro de eliminar el Proveedor {nombre} ?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm != QMessageBox.Yes:
            return

        del self.proveedores_registrados[fila]
        self.tblProveedor.removeRow(fila)
        self.grabar_proveedores()
        self.actualizar_total_proveedores()

        QMessageBox.information(self, "Éxito", f"Cliente '{nombre}' eliminado correctamente.")


    #9 ACTUALIZA LA TABLA MANUALMENTE
    def actualizar_tabla(self):
        self.cargar_proveedores_archivo()
        self.cargar_proveedores()
        QMessageBox.information(self, "Actualizado", "Tabla actualizada")


    # 10 ACTUALIZAR EL CONTADOR
    def actualizar_total_proveedores(self):
        if hasattr(self, "lblTotal"):
            total = self.tblProveedor.rowCount()
            # Solo ponemos el número (conviertiéndolo a texto con str)
            self.lblTotal.setText(str(total))




    def regresar_menu_desde_consulta_proveedores(self):
        from Vista.sisprincipal import MenuAPP
        self.ventana_menu = MenuAPP()
        self.ventana_menu.show()
        pass