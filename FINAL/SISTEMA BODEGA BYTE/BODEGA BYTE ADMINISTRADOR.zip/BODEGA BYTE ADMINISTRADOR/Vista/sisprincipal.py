from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication

class MenuAPP(QMainWindow):
    def __init__(self, parent = None):
        super(MenuAPP, self).__init__(parent)
        uic.loadUi("Ui/MENU_SISTEMA.ui" , self)
        self.setWindowTitle("MENU") 
        
        
        #CONEXION DE BOTONES
        
        self.btnSalirMenu.clicked.connect(self.salir_sistema)
        self.btnComprobante.clicked.connect(self.comprobrante_pago)
        self.btnRegistroProducto.clicked.connect(self.Registro_Productos)
        self.btnVerCliente.clicked.connect(self.ver_cliente)
        self.btnConsultaCliente.clicked.connect(self.consul_cliente)
        self.btnInventario.clicked.connect(self.inventario_admin)
        self.btnConsultaProveedores.clicked.connect(self.consul_proovedores)
        



    #AREA DE PROGRAMACION

    def comprobrante_pago(self):
        from Vista.comprobante import ComprobanteAPP
        self.ventana_comprobante = ComprobanteAPP()
        self.ventana_comprobante.show()
        pass

    def Registro_Productos(self):
        from Vista.regproducto import RegProductos
        self.ventana_regpro = RegProductos()
        self.ventana_regpro.show()
        pass

    def ver_cliente(self):
        from Vista.vercliente import VerCliente
        self.venta_vercli = VerCliente()
        self.venta_vercli.show()
        pass

    def consul_cliente(self):
        from Vista.consulcli import ConsultaCli
        self.consul_cli = ConsultaCli()
        self.consul_cli.show()
        pass

    def inventario_admin (self):
        from Vista.inventario import Inventario
        self.inven = Inventario()
        self.inven.show()
        pass

    def consul_proovedores (self):
        from Vista.consultaprov import ConsultaProveedores
        self.conprov = ConsultaProveedores()
        self.conprov.show()
        pass
    def salir_sistema(self):
        QApplication.quit()

        