from PyQt5 import uic, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox
from datetime import datetime
import os

class RegProductos(QMainWindow):
    def __init__(self, parent=None):
        super(RegProductos, self).__init__(parent)
        uic.loadUi("Ui/REGISTRO_PRODUCTO.ui", self)
        self.setWindowTitle("REGISTRO DE PRODUCTOS")

        self.productos = []
        self.cargar_archivo_productos()
        self.listar_productos()


        # Configuración inicial de la tabla
        self.configuracion_tabla()

        # Conexión de botones
        self.btnListar.clicked.connect(self.listar_productos)
        self.btnEditar.clicked.connect(self.abrir_edicion)
        self.btnNuevoPro.clicked.connect(self.limpiar_campos)
        self.btnGuardar.clicked.connect(self.guardar_producto)
        self.btnBuscar.clicked.connect(self.buscar_desde_form)
        self.btnBorrar.clicked.connect(self.abrir_form_eliminar)
        self.btnAgregarStock.clicked.connect(self.abrir_buscar_stock)
        self.btnRegresar.clicked.connect(self.regresar_menu_producto)
        self.txtPrecioCosto.textChanged.connect(self.calcular_igv_y_precio_venta)


    # Configuración de la tabla
    def configuracion_tabla(self):
        if not hasattr(self, "tblProductos"):
            return
        self.tblProductos.setColumnCount(12)
        encabezados = [
            "Código", "Proveedor", "RUC", "Categoría", "Marca", "U.Medida",
            "Estado", "Fecha de Registro", "Precio Costo", "IGV",
            "Precio Venta", "Stock Actual"
        ]
        self.tblProductos.setHorizontalHeaderLabels(encabezados)
        self.tblProductos.verticalHeader().setVisible(False)
        self.tblProductos.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.tblProductos.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)

    # Listar productos en la tabla
    def listar_productos(self):
        self.tblProductos.setRowCount(len(self.productos))
        for i, p in enumerate(self.productos):
            self.tblProductos.setItem(i, 0, QTableWidgetItem(p.get("codigo", "")))
            self.tblProductos.setItem(i, 1, QTableWidgetItem(p.get("Proveedor", "")))
            self.tblProductos.setItem(i, 2, QTableWidgetItem(p.get("RUC", "")))
            self.tblProductos.setItem(i, 3, QTableWidgetItem(p.get("Categoria", "")))
            self.tblProductos.setItem(i, 4, QTableWidgetItem(p.get("Marca", "")))
            self.tblProductos.setItem(i, 5, QTableWidgetItem(p.get("U.Medida", "")))
            self.tblProductos.setItem(i, 6, QTableWidgetItem(p.get("Estado", "")))
            self.tblProductos.setItem(i, 7, QTableWidgetItem(p.get("Fecha de Registro", "")))
            self.tblProductos.setItem(i, 8, QTableWidgetItem(p.get("Precio Costo", "")))
            self.tblProductos.setItem(i, 9, QTableWidgetItem(p.get("IGV", "")))
            self.tblProductos.setItem(i, 10, QTableWidgetItem(p.get("Precio Venta", "")))
            self.tblProductos.setItem(i, 11, QTableWidgetItem(p.get("Stock Actual", "")))

    # Limpiar tabla
    def limpiar_tabla(self):
        self.tblProductos.clearContents()
        self.tblProductos.setRowCount(0)

    # LIMPIA CAMPOS DE DATOS PARA INGRESAR NUEVOS DATOS
    def limpiar_campos(self):
        self.txtCodigo.clear()
        self.txtProveedor.clear()
        self.txtRuc.clear()
        self.txtCategoria.clear()
        self.txtMarca.clear()
        self.txtUnidadMedida.clear()
        self.txtEstado.clear()
        self.txtPrecioCosto.clear()
        self.txtIgv.clear()
        self.txtPrecioV.clear()
        self.txtStockAct.clear()

    # Guardar producto
    def guardar_producto(self):
        codigo = self.txtCodigo.text().strip()
        proveedor = self.txtProveedor.text().strip()
        ruc = self.txtRuc.text().strip()
        categoria = self.txtCategoria.text().strip()
        marca = self.txtMarca.text().strip()
        umedida = self.txtUnidadMedida.text().strip()
        estado = self.txtEstado.text().strip()
        costo = self.txtPrecioCosto.text().strip()
        igv = self.txtIgv.text().strip()
        venta = self.txtPrecioV.text().strip()
        stock = self.txtStockAct.text().strip()

        if (not codigo or not proveedor or not ruc or not categoria or 
            not marca or not umedida or not estado or not costo or 
            not igv or not venta or not stock):
            
            QMessageBox.warning(self, "Faltan Datos", "No se puede guardar. Todos los campos son obligatorios.")
            return 

        for p in self.productos:
            if p["codigo"] == codigo:
                QMessageBox.warning(self, "Error", "El código ya existe")
                return

        producto = {
            "codigo": codigo,
            "Proveedor": proveedor,
            "RUC": ruc,
            "Categoria": categoria,
            "Marca": marca,
            "U.Medida": umedida,
            "Estado": estado,
            "Fecha de Registro": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "Precio Costo": costo,
            "IGV": igv,
            "Precio Venta": venta,
            "Stock Actual": stock,
        }

        self.productos.append(producto)
        self.guardar_archivo_productos()
        QMessageBox.information(self, "Éxito", "Producto guardado correctamente")
        
        self.limpiar_campos()
        self.listar_productos()

    # Buscar producto desde pequeño formulario
    def buscar_desde_form(self):
        self.form_buscar_producto = QMainWindow()
        uic.loadUi("Ui/FORM_BUSCAR_PRODUCTO.ui", self.form_buscar_producto)
        self.form_buscar_producto.btnBuscar.clicked.connect(self.buscar_producto)
        self.form_buscar_producto.show()

    def buscar_producto(self):
        codigo_buscar = self.form_buscar_producto.txtCodigo.text().strip()
        proveedor_buscar = self.form_buscar_producto.txtProveedor.text().strip()
        ruc_buscar = self.form_buscar_producto.txtRuc.text().strip()

        if not codigo_buscar and not proveedor_buscar and not ruc_buscar:
            QMessageBox.warning(self, "Error", "Ingrese algún valor para buscar")
            return

        self.tblProductos.clearContents()
        self.tblProductos.setRowCount(0)

        producto_encontrado = None
        for p in self.productos:
            if ((codigo_buscar and p.get("codigo", "") == codigo_buscar) or
                (proveedor_buscar and proveedor_buscar.lower() in p.get("Proveedor", "").lower()) or
                (ruc_buscar and p.get("RUC", "") == ruc_buscar)):

                producto_encontrado = p
                self.tblProductos.setRowCount(1)
                for col, key in enumerate(["codigo","Proveedor","RUC","Categoria","Marca","U.Medida",
                                           "Estado","Fecha de Registro","Precio Costo","IGV","Precio Venta","Stock Actual"]):
                    self.tblProductos.setItem(0, col, QTableWidgetItem(p.get(key,"")))
                QMessageBox.information(self, "Buscar", "Producto encontrado")
                break

        if not producto_encontrado:
            QMessageBox.information(self, "Buscar", "Producto no encontrado")

    # Cargar formulario de edición
    def cargar_edicion(self):
        codigo_buscar = self.form_buscar_producto.txtCodigo.text().strip()
        proveedor_buscar = self.form_buscar_producto.txtProveedor.text().strip()
        ruc_buscar = self.form_buscar_producto.txtRuc.text().strip()

        producto_encontrado = None
        for p in self.productos:
            if ((codigo_buscar and p.get("codigo", "") == codigo_buscar) or
                (proveedor_buscar and proveedor_buscar.lower() in p.get("Proveedor", "").lower()) or
                (ruc_buscar and p.get("RUC", "") == ruc_buscar)):
                producto_encontrado = p
                break

        if not producto_encontrado:
            QMessageBox.information(self, "Editar", "Producto no encontrado")
            return

        self.form_editar = QMainWindow()
        uic.loadUi("Ui/FORM_EDITAR_PRODUCTO_GENERAL.ui", self.form_editar)

        # Precargar los campos
        self.form_editar.txtCodigo.setText(producto_encontrado.get("codigo",""))
        self.form_editar.txtProveedor.setText(producto_encontrado.get("Proveedor",""))
        self.form_editar.txtRuc.setText(producto_encontrado.get("RUC",""))
        self.form_editar.txtCategoria.setText(producto_encontrado.get("Categoria",""))
        self.form_editar.txtMarca.setText(producto_encontrado.get("Marca",""))
        self.form_editar.txtUMedida.setText(producto_encontrado.get("U.Medida",""))
        self.form_editar.txtEstado.setText(producto_encontrado.get("Estado",""))
        self.form_editar.txtPrecioC.setText(producto_encontrado.get("Precio Costo",""))
        self.form_editar.txtIgv.setText(producto_encontrado.get("IGV",""))
        self.form_editar.txtPrecioV.setText(producto_encontrado.get("Precio Venta",""))
        self.form_editar.txtStockAct.setText(producto_encontrado.get("Stock Actual",""))

        self.form_editar.txtPrecioC.textChanged.connect(
            lambda: self.calcular_igv_y_precio_venta_edicion(self.form_editar)
        )

        # Conectar botones
        self.form_editar.btnGuardar.clicked.connect(lambda: self.guardar_cambios(producto_encontrado))
        self.form_editar.btnCancelar.clicked.connect(self.form_editar.close)
        self.form_editar.show()

    # Guardar cambios en producto editado
    def guardar_cambios(self, producto):
        fg = self.form_editar
        for key, widget in [("Proveedor", fg.txtProveedor), ("RUC", fg.txtRuc), ("Categoria", fg.txtCategoria),
                            ("Marca", fg.txtMarca), ("U.Medida", fg.txtUMedida), ("Estado", fg.txtEstado),
                            ("Precio Costo", fg.txtPrecioC), ("IGV", fg.txtIgv), ("Precio Venta", fg.txtPrecioV),
                            ("Stock Actual", fg.txtStockAct)]:
            if widget.text().strip():
                producto[key] = widget.text()
        self.guardar_archivo_productos()
        self.listar_productos()
        QMessageBox.information(self, "Editar", "Producto actualizado correctamente")
        fg.close()

    # Abrir ventana de edición
    def abrir_edicion(self):
        self.form_buscar_producto = QMainWindow()
        uic.loadUi("Ui/FORM_EDITAR_PRODUCTO.ui", self.form_buscar_producto)
        self.form_buscar_producto.btnBuscar.clicked.connect(self.cargar_edicion)
        self.form_buscar_producto.show()

    # Eliminar producto desde formulario
    def eliminar_producto_desde_form(self):
        codigo = self.form_eliminar.txtCodigo.text().strip().lower()
        proveedor = self.form_eliminar.txtProveedor.text().strip().lower()
        ruc = self.form_eliminar.txtRuc.text().strip().lower()

        if not codigo and not proveedor and not ruc:
            QMessageBox.warning(self, "Eliminar", "Ingrese Código, Proveedor o RUC para eliminar")
            return

        encontrado = False

        for i, p in enumerate(self.productos):
            codigo_prod = str(p.get("codigo", "")).strip().lower()
            proveedor_prod = str(p.get("Proveedor", "")).strip().lower()
            ruc_prod = str(p.get("RUC", "")).strip().lower()

            if ((codigo and codigo == codigo_prod) or
                (proveedor and proveedor == proveedor_prod) or
                (ruc and ruc == ruc_prod)):

                del self.productos[i]  # Borra el producto
                self.listar_productos()  # Actualiza tabla
                self.guardar_archivo_productos()  # Guarda cambios
                QMessageBox.information(self, "Éxito", "Producto eliminado correctamente")
                # Limpiar campos del formulario
                self.form_eliminar.txtCodigo.clear()
                self.form_eliminar.txtProveedor.clear()
                self.form_eliminar.txtRuc.clear()
                encontrado = True
                break

        if not encontrado:
            QMessageBox.warning(self, "Eliminar", "No se encontró ningún producto con esos datos")


    # Abrir formulario de eliminación
    def abrir_form_eliminar(self):
        self.form_eliminar = QMainWindow()
        uic.loadUi("Ui/FORM_ELIMINAR_PRODUCTO.ui", self.form_eliminar)
        self.form_eliminar.btnEliminar.clicked.connect(self.eliminar_producto_desde_form)
        self.form_eliminar.show()

    # Agregar stock
    def abrir_buscar_stock(self):
        self.win_buscar_stock = QMainWindow()
        uic.loadUi("Ui/BUSCAR_STOCK_AGREGAR.ui", self.win_buscar_stock)
        self.win_buscar_stock.btnBuscar.clicked.connect(self.buscar_producto_para_stock)
        self.win_buscar_stock.show()

    def buscar_producto_para_stock(self):
        codigo = self.win_buscar_stock.txtCodigo.text().strip()
        proveedor = self.win_buscar_stock.txtProveedor.text().strip()
        ruc = self.win_buscar_stock.txtRuc.text().strip()

        if not codigo and not proveedor and not ruc:
            QMessageBox.warning(self, "Error", "Debe ingresar código, proveedor o RUC.")
            return

        self.producto_encontrado = None
        for p in self.productos:
            if ((codigo and p["codigo"] == codigo) or
                (proveedor and proveedor.lower() in p["Proveedor"].lower()) or
                (ruc and p["RUC"] == ruc)):
                self.producto_encontrado = p
                break

        if not self.producto_encontrado:
            QMessageBox.warning(self, "No encontrado", "No existe un producto con esos datos.")
            return

        self.win_agregar_stock = QMainWindow()
        uic.loadUi("Ui/AGREGAR_STOCK.ui", self.win_agregar_stock)
        self.win_agregar_stock.lblProducto.setText(
            f"{self.producto_encontrado['codigo']} - {self.producto_encontrado['Proveedor']}"
        )
        self.win_agregar_stock.btnAgregar.clicked.connect(self.agregar_stock_confirmado)
        self.win_agregar_stock.show()

    def agregar_stock_confirmado(self):
        cantidad = self.win_agregar_stock.txtCantidad.text().strip()

        if not cantidad.isdigit():
            QMessageBox.warning(self, "Error", "La cantidad debe ser un número.")
            return

        nuevo_stock = int(self.producto_encontrado.get("Stock Actual", "0")) + int(cantidad)
        self.producto_encontrado["Stock Actual"] = str(nuevo_stock)

        self.listar_productos()
        self.guardar_archivo_productos()  # <-- guardar cambios en archivo

        QMessageBox.information(self, "Éxito", "Stock agregado correctamente.")
        self.win_agregar_stock.close()
        self.win_buscar_stock.close()

    # Cargar productos desde archivo
    def cargar_archivo_productos(self):
        ruta = "Modelo/Productos.txt"
        self.productos = []

        if not os.path.exists(ruta):
            return

        with open(ruta, "r", encoding="utf-8") as f:
            for linea in f:
                datos = linea.strip().split(";")
                if len(datos) == 12:
                    self.productos.append({
                        "codigo": datos[0],
                        "Proveedor": datos[1],
                        "RUC": datos[2],
                        "Categoria": datos[3],
                        "Marca": datos[4],
                        "U.Medida": datos[5],
                        "Estado": datos[6],
                        "Fecha de Registro": datos[7],
                        "Precio Costo": datos[8],
                        "IGV": datos[9],
                        "Precio Venta": datos[10],
                        "Stock Actual": datos[11]
                    })

    # Guardar productos en archivo
    def guardar_archivo_productos(self):
        ruta = "Modelo/Productos.txt"

        with open(ruta, "w", encoding="utf-8") as f:
            for p in self.productos:
                linea = ";".join([
                    p["codigo"],
                    p["Proveedor"],
                    p["RUC"],
                    p["Categoria"],
                    p["Marca"],
                    p["U.Medida"],
                    p["Estado"],
                    p["Fecha de Registro"],
                    p["Precio Costo"],
                    p["IGV"],
                    p["Precio Venta"],
                    p["Stock Actual"]
                ])
                f.write(linea + "\n")

    # Editar producto en archivo (utilitario)
    def editar_en_archivo(self, codigo, nuevos_datos):
        for p in self.productos:
            if p["codigo"] == codigo:
                p.update(nuevos_datos)
                break
        self.guardar_archivo_productos()

    # Borrar producto en archivo (utilitario)
    def borrar_en_archivo(self, codigo):
        self.productos = [p for p in self.productos if p["codigo"] != codigo]
        self.guardar_archivo_productos()

    # Regresar al menú
    def regresar_menu_producto(self):
        from Vista.sisprincipal import MenuAPP
        self.ventana_menu = MenuAPP()
        self.ventana_menu.show()
    def calcular_igv_y_precio_venta(self):
        try:
            costo = float(self.txtPrecioCosto.text())
            igv = costo * 0.18
            precio_venta = costo + igv

            self.txtIgv.setText(f"{igv:.2f}")
            self.txtPrecioV.setText(f"{precio_venta:.2f}")

        except ValueError:
            # Si no es número, limpiar
            self.txtIgv.clear()
            self.txtPrecioV.clear()
    def calcular_igv_y_precio_venta_edicion(self, form):
        try:
            costo = float(form.txtPrecioC.text())
            igv = costo * 0.18
            precio_venta = costo + igv

            form.txtIgv.setText(f"{igv:.2f}")
            form.txtPrecioV.setText(f"{precio_venta:.2f}")

        except ValueError:
            form.txtIgv.clear()
            form.txtPrecioV.clear()
