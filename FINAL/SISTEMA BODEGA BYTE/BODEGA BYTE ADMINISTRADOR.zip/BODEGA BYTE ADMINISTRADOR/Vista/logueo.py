import hashlib
import socket
from datetime import datetime
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QMessageBox


# ------------------- Clase principal -------------------
class LoguearseApp(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Ui/LOGIN.ui" , self)
        self.setWindowTitle("LOGIN - BOGEDA BYTE")

        # CONEXIONES DE BOTONES
        self.btnIngresar.clicked.connect(self.validar_login)
        self.btnSalir.clicked.connect(self.close)

        # Validación de usuario
        self.usuario_registrado = "ADMINISTRADOR"
        self.hash_guardado = self.encriptar_sha256("1234")

        # Ocultar caracteres de la contraseña
        self.txtContrasena.setEchoMode(2)

        # Listas temporales
        self.clientes_registrados = []
        self.productos_registrados = []
        self.proveedores_registrados = []
        self.inventario_registrado = []


    # ------------------- Función SHA256 -------------------
    def encriptar_sha256(self, texto):
        return hashlib.sha256(texto.encode('utf-8')).hexdigest()


    # ------------------- VALIDAR LOGIN -------------------
    def validar_login(self):
        usuario = self.txtUsuario.text()
        contrasena = self.txtContrasena.text()
        
        hash_contra = self.encriptar_sha256(contrasena)
        sha_valida = self.encriptar_sha256("1234")

        # ---------------------------------------
        #           LOGIN CORRECTO
        # ---------------------------------------
        if usuario == "ADMINISTRADOR" and hash_contra == sha_valida:
            QMessageBox.information(self, "Acceso permitido", "Bienvenido al sistema, Administrador.")
            self.abrir_menu()
            self.close()
            return

        # ---------------------------------------
        #           LOGIN INCORRECTO
        # ---------------------------------------
        QMessageBox.warning(self, "Acceso denegado", "Usuario o contraseña incorrectos.")

        # === Registrar intento fallido con fecha, hora e IP ===
        try:
            fecha_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ip_local = socket.gethostbyname(socket.gethostname())

            with open("intentos_fallidos.txt", "a", encoding="utf-8") as archivo:
                archivo.write(
                    f"{fecha_hora} - Usuario: {usuario} - Intento fallido - IP: {ip_local}\n"
                )

        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo registrar el intento fallido: {e}")

        # Limpiar campos para intentar nuevamente
        self.txtContrasena.clear()
        self.txtUsuario.setFocus()


    # ------------------- ABRIR MENU PRINCIPAL -------------------
    def abrir_menu(self):
        from Vista.sisprincipal import MenuAPP
        self.ventana_menu = MenuAPP()
        self.ventana_menu.show()

    # ------------------- CERRAR LOGIN -------------------
    def cerrar_login(self):
        self.close()
