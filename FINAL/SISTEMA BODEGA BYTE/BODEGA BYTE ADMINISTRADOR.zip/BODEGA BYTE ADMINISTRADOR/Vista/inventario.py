from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow

class Inventario(QMainWindow):
    def __init__(self, parent = None):
        super(Inventario, self).__init__(parent)
        uic.loadUi("Ui/INVENTARIO_OP.ui", self)
        self.setWindowTitle("INVENTARIO ADMIN") 

    #CONEXION DE BOTONES

        self.btnRegresarInventario.clicked.connect(self.regresar_menu_desde_inventario)
        self.btnListaDeInventario.clicked.connect(self.entrar_listainvario)
        self.btnSalidaDeInventario.clicked.connect(self.salida_de_inventario)

    #AREA DE PROGRAMACION
    
    def entrar_listainvario(self):
        from Vista.listainv import ListaInventario
        self.ventana_listinv = ListaInventario()
        self.ventana_listinv.show()
        self.close()

    def salida_de_inventario(self):
        from Vista.salidainv import SalidaInventario
        self.ventana_salinv = SalidaInventario()
        self.ventana_salinv.show()
        self.close()


    def regresar_menu_desde_inventario(self):
        from Vista.sisprincipal import MenuAPP
        self.ventana_menu = MenuAPP()
        self.ventana_menu.show()
        pass