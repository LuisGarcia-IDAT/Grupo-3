from PyQt5 import uic
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem
from datetime import datetime
import os


class ListaInventario(QMainWindow):

    RUTA = "Modelo/Inventario.txt"  

    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi("Ui/LISTA_INVENTARIO.ui", self)

        self.productos = []
        os.makedirs("Modelo", exist_ok=True)

        self.cargar_archivo()
        self.cargar_tabla()
        self.conectar_botones()

    # -------------------------------------------------------------------
    def conectar_botones(self):
        self.btnRegresarLista.clicked.connect(self.regresar_inventario)
        self.btnAgregarProducto.clicked.connect(self.abrir_form)
        self.btnBuscar.clicked.connect(self.buscar)
        self.btnDeshabilitar.clicked.connect(self.deshabilitar)
        self.btnAlertas.clicked.connect(self.generar_alertas)
        self.btnEditar.clicked.connect(self.editar_producto)


    # -------------------------------------------------------------------
    def abrir_form(self):
        self.form = uic.loadUi("Ui/FORM_INVENTARIO.ui")
        self.form.txtFechaActualizacion.setText(datetime.now().strftime("%d/%m/%Y"))

        self.form.btnGuardarProducto.clicked.connect(self.guardar_desde_form)
        self.form.btnCancelar.clicked.connect(self.form.close)

        self.form.show()

    # -------------------------------------------------------------------
    def guardar_desde_form(self):
        f = self.form

        # datos básicos
        codigo = f.txtCodigo.text().strip()
        nombre = f.txtProducto.text().strip()
        categoria = f.txtCategoria.text().strip()
        precio = f.txtPrecio.text().strip()
        stock = f.txtStock.text().strip()
        stock_min = f.txtStockMin.text().strip()
        estado = f.cboEstado.currentText().strip()
        proveedor = f.txtProveedor.text().strip()
        fecha = f.txtFechaActualizacion.text().strip()

        if codigo == "" or nombre == "":
            QMessageBox.warning(self, "Error", "Código y nombre son obligatorios.")
            return

        # convertir números (si fallan → 0)
        try:
            stock_i = int(stock)
        except:
            stock_i = 0
        try:
            stock_min_i = int(stock_min)
        except:
            stock_min_i = 0

        # alerta simple
        if stock_i < stock_min_i:
            alerta = "Rojo"
        elif stock_i == stock_min_i:
            alerta = "Amarillo"
        else:
            alerta = "Verde"

        fila_data = [codigo, nombre, categoria, precio, str(stock_i), str(stock_min_i), alerta, estado, fecha, proveedor]

        # agregar a tabla
        fila = self.tblInventario.rowCount()
        self.tblInventario.insertRow(fila)
        for col, val in enumerate(fila_data):
            self.tblInventario.setItem(fila, col, QTableWidgetItem(val))

        # guardar en archivo
        with open(self.RUTA, "a", encoding="utf-8") as ftxt:
            ftxt.write("|".join(fila_data) + "\n")

        QMessageBox.information(self, "OK", "Producto guardado.")
        self.colorear_fila(fila)
        self.actualizar_barras()
        self.actualizar_panel_derecho()
        f.close()

    # -------------------------------------------------------------------
    def cargar_archivo(self):
        self.productos.clear()
        if not os.path.exists(self.RUTA):
            open(self.RUTA, "w", encoding="utf-8").close()
            return

        with open(self.RUTA, "r", encoding="utf-8") as f:
            for linea in f:
                partes = linea.strip().split("|")
                if len(partes) == 10:
                    self.productos.append(partes)

    # -------------------------------------------------------------------
    def cargar_tabla(self):
        self.tblInventario.setRowCount(0)
        for prod in self.productos:
            fila = self.tblInventario.rowCount()
            self.tblInventario.insertRow(fila)
            for col, val in enumerate(prod):
                self.tblInventario.setItem(fila, col, QTableWidgetItem(val))
            self.colorear_fila(fila)
        self.actualizar_barras()
        self.actualizar_panel_derecho()

    # -------------------------------------------------------------------
    def buscar(self):
        texto = self.txtBuscarProducto.text().lower().strip()
        for i in range(self.tblInventario.rowCount()):
            visible = False
            for j in range(self.tblInventario.columnCount()):
                item = self.tblInventario.item(i, j)
                if item and texto in item.text().lower():
                    visible = True
                    break
            self.tblInventario.setRowHidden(i, not visible)

    # -------------------------------------------------------------------
    def deshabilitar(self):
        fila = self.tblInventario.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione un producto.")
            return

        stock = int(self.tblInventario.item(fila, 4).text())
        if stock > 0:
            QMessageBox.warning(self, "Error", "Solo se deshabilita con stock 0.")
            return

        self.tblInventario.setItem(fila, 7, QTableWidgetItem("Deshabilitado"))
        self.guardar_tabla_completa()
        self.actualizar_panel_derecho()
        QMessageBox.information(self, "OK", "Producto deshabilitado.")

    # -------------------------------------------------------------------
    def guardar_tabla_completa(self):
        with open(self.RUTA, "w", encoding="utf-8") as f:
            for i in range(self.tblInventario.rowCount()):
                fila = []
                for j in range(self.tblInventario.columnCount()):
                    item = self.tblInventario.item(i, j)
                    fila.append(item.text() if item else "")
                f.write("|".join(fila) + "\n")
        self.actualizar_panel_derecho()

    # -------------------------------------------------------------------
    def colorear_fila(self, fila):
        alerta = self.tblInventario.item(fila, 6).text().lower()

        if alerta == "verde":
            color = "#C4FFC4"
        elif alerta == "amarillo":
            color = "#FFF7A5"
        else:
            color = "#FF8A8A"

        for c in range(self.tblInventario.columnCount()):
            item = self.tblInventario.item(fila, c)
            if item:
                item.setBackground(QColor(color))

    # -------------------------------------------------------------------
    def actualizar_barras(self):
        total = self.tblInventario.rowCount()
        if total == 0:
            self.progressVerde.setValue(0)
            self.progressRojo.setValue(0)
            return

        buenos = 0
        for i in range(total):
            stock = int(self.tblInventario.item(i, 4).text())
            stock_min = int(self.tblInventario.item(i, 5).text())
            if stock >= stock_min:
                buenos += 1

        porcentaje = int(buenos / total * 100)
        self.progressVerde.setValue(porcentaje)
        self.progressRojo.setValue(100 - porcentaje)

    # -------------------------------------------------------------------
    def generar_alertas(self):
        self.lstAlertas.clear()
        hay = False

        for i in range(self.tblInventario.rowCount()):
            nombre = self.tblInventario.item(i, 1).text()
            stock = int(self.tblInventario.item(i, 4).text())
            stock_min = int(self.tblInventario.item(i, 5).text())

            if stock < stock_min:
                self.lstAlertas.addItem(f"🔴 {nombre} está AGOTADO.")
                hay = True
            elif stock == stock_min:
                self.lstAlertas.addItem(f"🟡 {nombre} está por acabarse.")
                hay = True

        if not hay:
            self.lstAlertas.addItem("✅ No hay alertas.")

    # -------------------------------------------------------------------
    def regresar_inventario(self):
        from Vista.inventario import Inventario
        ventana = Inventario()
        ventana.show()
        self.close()
    def calcular_stock_total(self):
        total = 0
        filas = self.tblInventario.rowCount()

        for i in range(filas):
            item = self.tblInventario.item(i, 4)  # columna Stock
            if item is not None:
                try:
                    total += int(item.text())
                except ValueError:
                    pass  # si algo no es número, simplemente no se suma

        return total
    def actualizar_panel_derecho(self):
        total_stock = self.calcular_stock_total()
        total_desh = self.contar_deshabilitados()

        self.lblStockTotal.setText(f"Stock total: {total_stock}")
        self.lblProductosAgotados.setText(f"Productos deshabilitados: {total_desh}")

    def contar_deshabilitados(self):
        total = 0
        filas = self.tblInventario.rowCount()

        for i in range(filas):
            item = self.tblInventario.item(i, 7)  # columna Estado
            if item and item.text().strip().lower() == "deshabilitado":
                total += 1

        return total
    def editar_producto(self):
        fila = self.tblInventario.currentRow()

        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione un producto para editar.")
            return

        # Abrir formulario
        self.form = uic.loadUi("Ui/FORM_INVENTARIO.ui")
        self.form.setWindowTitle("Editar Producto")

        # Cargar datos actuales en los campos
        self.form.txtCodigo.setText(self.tblInventario.item(fila, 0).text())
        self.form.txtProducto.setText(self.tblInventario.item(fila, 1).text())
        self.form.txtCategoria.setText(self.tblInventario.item(fila, 2).text())
        self.form.txtPrecio.setText(self.tblInventario.item(fila, 3).text())
        self.form.txtStock.setText(self.tblInventario.item(fila, 4).text())
        self.form.txtStockMin.setText(self.tblInventario.item(fila, 5).text())
        self.form.cboEstado.setCurrentText(self.tblInventario.item(fila, 7).text())
        self.form.txtFechaActualizacion.setText(self.tblInventario.item(fila, 8).text())
        self.form.txtProveedor.setText(self.tblInventario.item(fila, 9).text())

        # Guardar cambios
        self.form.btnGuardarProducto.clicked.connect(lambda: self.guardar_edicion(fila))

        # Cancelar
        self.form.btnCancelar.clicked.connect(self.form.close)

        self.form.show()
    def guardar_edicion(self, fila):
        f = self.form

        codigo = f.txtCodigo.text().strip()
        nombre = f.txtProducto.text().strip()
        categoria = f.txtCategoria.text().strip()
        precio = f.txtPrecio.text().strip()

        try:
            stock = int(f.txtStock.text().strip())
        except:
            stock = 0

        try:
            stock_min = int(f.txtStockMin.text().strip())
        except:
            stock_min = 0

        estado = f.cboEstado.currentText().strip()
        proveedor = f.txtProveedor.text().strip()
        fecha = f.txtFechaActualizacion.text().strip()

        # Recalcular alerta
        if stock < stock_min:
            alerta = "Rojo"
        elif stock == stock_min:
            alerta = "Amarillo"
        else:
            alerta = "Verde"

        valores = [codigo, nombre, categoria, precio, str(stock),
                str(stock_min), alerta, estado, fecha, proveedor]

        # Guardar en tabla
        for col, val in enumerate(valores):
            self.tblInventario.setItem(fila, col, QTableWidgetItem(val))

        # Recolorear fila
        self.colorear_fila(fila)

        # Guardar archivo completo
        self.guardar_tabla_completa()

        # Actualizar panel derecho
        self.actualizar_panel_derecho()

        QMessageBox.information(self, "OK", "Producto editado correctamente.")

        f.close()





